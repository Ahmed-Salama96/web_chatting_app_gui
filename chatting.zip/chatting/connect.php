<?php
  require 'database.php';
  $email=$_POST['email'];
  $pas=$_POST['pass'];
  $query="SELECT * FROM users WHERE Email='$email' AND Password='$pas'";
  $res=mysqli_query($con,$query);
  $row=mysqli_fetch_array($res);
  if(!$row)
   {
     die("Email address /or password error");
     header("refrech:2; url='login.html'");

   }
  else
   {
    session_start();
    $_SESSION['x']=$email;
    header('location:mail.php');
   }
?>