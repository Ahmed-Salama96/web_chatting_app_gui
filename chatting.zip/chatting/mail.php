<?php
   session_start();
   $email=$_SESSION['email'];
   $pass=$_SESSION['pass'];
	require 'database.php';
	$q=" SELECT * FROM users WHERE Email='$email' AND Password= '$pass' ";
   $res=mysqli_query($con,$q);
   $row=mysqli_fetch_array($res);			
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
 <head>
    <meta charset="UTF-8">
    <title>ChatBook -profile</title>
    <link rel="icon" type="image/png" href="icon2.png">
    <meta name="description" content=" ChatBook is messageing system through you can be always connected with your friends!">
    <meta name="keywords" content=" chat ; book ; friends ; ChatBook ; talk ; login ">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link type="text/css" rel="stylesheet" href="style.css">
 </head>
 <body>

 <!-- the head of the page -->
  <div id="simple">
         <div id="profIcon">
          <a href="index.html" content="home page" id="ref">
            <img src="icon2.png" id="home" content="Home" onclick="window">
            <span style="font-size:x-large;" class="username">  ChatBook   </span>
          </a>
         </div>
         <a href="profile.php" content="home page" id="pic">
           <img src="default2.jpg" content="profile" height="35px" width="35px">
           <span style="font-size:x-large;" class="username">  Ahmed salama  </span>
         </a>
         <a href="index.html" class="logoutButton" id="l">  Logout  </a> 
         <a href="mail.php" class="logoutButton" id="h">  Home  </a>  
           
  </div>
  <!-- the body of the page -->
  <div >
    <!-- the left side of the page -->
    <div id="list">
         <!-- the search are search by the Email Address only  -->
         <div id="srch">
             <form name="searchForm" method="get" action="">
                <input type="image" src="12.png"  id="subSrch" alt="submit" border="0">
                 <input type= "search" class="search" placeholder="Search" required >
                 
              </form>
         </div>
         
         <div class="contacts"> 
           <img src="icon2.png" alt="user photo" height="48px" width="48px" style="float:left;">
            <h3>Ahmed sheta</h3>
         </div>
         <div class="contacts"> 
            <img src="icon2.png" alt="user photo" height="48px" width="48px" style="float:left;">
            <h3 >Ahmed sheta</h3>
         </div>
    </div>
    <!-- the right side of the page in which you can write your message -->  
    <div id="write">
       <!-- the username and picture -->
       <div id="disp">
            <img src="icon2.png" alt="user photo" height="48px" width="48px" style="float:left;">
            <h3  style="margin-top: 10px;">Ahmed sheta</h3>
       </div>
       <!-- the messages between you -->
       <div id="message">

         <div id="messageSent">
            <img src="icon2.png" alt="user photo" height="40px" width="40px">
            <span>Hello my friend how are you now</span>
       </div>
       <div id="messageSent" style="float:right;"> 
            <span style="background-color:cyan;">I'm just fine and U? </span>
            <img src="default2.jpg" alt="user photo" height="40px" width="40px">
       </div>

                 
       </div>
              
       <!-- this the area that you type in your message -->
       <div style="border-radius:20px">
         <form name="send" accept="" onsubmit="" >
             <input type="text" required="" class="send" placeholder="Type your message..."> 
             <input type="submit" name="submit" class="sendButton" value="Send">      
         </form>  
       </div>  
    </div>
  </div>
  <div id="footer">
       <p>This website created by the students &nbsp;
          <a href="https://www.facebook.com/AhmedSalamaShaaban" target="_" id="ahmed">Ahmed salama& </a>
          <a href="https://www.facebook.com/asheta0" target="_" id="ahmed"> Ahmed Sheta</a> 
        </p>
        <p>Contact us: a.salamaa595@gmail.com</p>
        <p>Phone: 01120878297</p>
        
    </div>
  <script type="text/javascript" src="script.js"></script>
 </body>
</html>