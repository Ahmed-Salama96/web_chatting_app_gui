<?php
  require 'database.php';
  $name=$_POST['name'];
  $birth=$_POST['birth'];
  $email=$_POST['email'];
  $six=$_POST['six'];
  $pass=$_POST['pass1'];
  
  $query= "SELECT Email FROM users ";
  $res=mysqli_query($con,$query)
  $row=mysqli_fetch_array($res);
  if(!$row)
 {
    die("Sorry i cannot add you now, please try again later ");
    header("Refresh: 2; url= index.html");
 }
  $os = $row['Email'];
if (in_array($email, $os) || strlen($pass)<6 ) {
    die("Sorry this email is here, please try another Email address ");
    header("Refresh: 2; url=index.html");
}
  $q="INSERT INTO users(Name, Email, Password, Sex, Birth) VALUES ('$name', '$email', '$pass', '$six', '$date')";
 if(!mysqli_query($con,$q))
 {
    die("Sorry i cannot add you now, please try again later ");
    header("Refresh: 2; url=index.html");
 }
 else
 {
	 session_start();
	 $_SESSION['email']=$_POST['email'];
	 $_SESSION['pass']=$_POST['pass1'];
    header('Location: profile.php');
 }
?>