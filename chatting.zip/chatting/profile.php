<?php
   session_start();
   /*if(isset($_SESSION['x']) {
        //session is set
        header('Location: /index.php');
    }*/ 
   $email=$_SESSION['email'];
   $pass=$_SESSION['pass'];
	require 'database.php';
	$q=" SELECT * FROM users WHERE Email='$email' AND Password= '$pass' ";
   $res=mysqli_query($con,$q);
   $row=mysqli_fetch_array($res);			
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
 <head>
    <meta charset="UTF-8">
    <title>ChatBook -profile</title>
    <link rel="icon" type="image/png" href="icon2.png">
    <meta name="description" content=" ChatBook is messageing system through you can be always connected with your friends!">
    <meta name="keywords" content=" chat ; book ; friends ; ChatBook ; talk ; login ">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link type="text/css" rel="stylesheet" href="style.css">
 </head>
 <body>

 <!-- the head of the page -->
  <div id="simple">
         <div id="profIcon">
          <a href="index.html" content="home page" id="ref">
            <img src="icon2.png" id="home" content="Home" onclick="window">
            <span style="font-size:x-large;">  ChatBook   </span>
          </a>
         </div>
         <a href="profile.php" content="home page" id="pic">
           <img src="default2.jpg" content="profile" height="35px" width="35px">
           <span style="font-size:x-large;">  Ahmed salama  </span>
         </a>
         <a href="index.html" class="logoutButton" id="l">  Logout  </a> 
         <a href="mail.php" class="logoutButton" id="h">  Home  </a>  
           
  </div>
  <!-- the left div which contain the profile and cover pictures -->
 <div id="profPage" style="width:100%;">
  <div id="profDiv" >
         <div id="covPic" onmouseover="showCover()" class="container">            
            <img src="cover.png" alt="cover picture" height="300px" width="100%" class="profile-pic"> 
             <div class="overlay"></div>
           <div class="button">
               <a href="#" >Change</a>
             </div>              
         </div>
         <div id="prfPic" onmouseover="showCover()" class="container">
             <img src="default2.jpg" alt="profile picture"height="150px" width="150px">
             <div class="overlay2"></div>
             <div class="button2"><a href="#"> Change </a></div> 
         </div>
        
         <span id="name"> Ahmed salama </span>
         <div id="intro">
            <h1>Introduction</h1>
            <textarea rows="7" cols="64">asdkjshad</textarea>  
         </div>
  </div>
  
  <!-- the right div which contains the information -->
  <div id="info">
    <table class="infoTable" >       
        <tr>
          <td>Email: </td>
          <td><?php echo $row['Email']; ?></td>        
        </tr>
        <tr>
          <td>phone number</td>
          <td><?php echo $row['Phone']; ?></td>        
        </tr>
        <tr>
          <td>Birthdate: </td>
          <td><?php echo $row['Birth']; ?></td>        
        </tr>
        <tr>
          <td>Six:</td>
          <td><?php echo $row['Sex']; ?></td>        
        </tr>
        <tr>
          <td>Interested in: </td>
          <td><?php echo $row['Interest']; ?></td>        
        </tr>     
    </table>  
  </div>
 </div>
  <div id="footer">
        <p>This website created by the students &nbsp;
          <a href="https://www.facebook.com/AhmedSalamaShaaban" target="_" id="ahmed">Ahmed salama& </a>
          <a href="https://www.facebook.com/asheta0" target="_" id="ahmed"> Ahmed Sheta</a> 
        </p>
        <p>Contact us: a.salamaa595@gmail.com</p>
        <p>Phone: 01120878297</p>
        
    </div>
<script type="text/javascript" src="script.js"></script>
</body>
</html>