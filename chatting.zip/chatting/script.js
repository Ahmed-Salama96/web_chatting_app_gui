/**
 * Created by kali on 9/7/17.
 */
function testEmail(){
    var reg = /^[a-zA-z][a-zA-Z0-9_\.]+@yahoo\.com$|@gmail\.com$/;
    var reg2 =/\w/;
    var name= document.create.name.value;
    var email = document.create.email.value;
    var pas1= document.crete.pass1.value;
    var pas2= document.create.pass2.value;
    if(! reg2.test(name)){
        alert("Your name must be characters only!");
        return false;
    }
    if(! reg.test(email)){
        alert("Your Email is wrong check it again please!");
        return false;
    }
    if(pas1.length != pas2.length)
    {
        alert("Password don't matches!")
        return false;
    }

}
function testLogin() { 
    var email = document.log.email.value;
    var reg = /^[a-zA-z][a-zA-Z0-9_\.]+@yahoo\.com$|@gmail\.com$/;
    if (reg.test(email) {
    	 return true;
    	 }
    else {
    	 alert("Enter valid Email please! ")
    	 return false;
    	}
}

$(document).ready(function() {

    
    var readURL = function(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('.profile-pic').attr('src', e.target.result);
            }
    
            reader.readAsDataURL(input.files[0]);
        }
    }
    

    $(".file-upload").on('change', function(){
        readURL(this);
    });
    
    $(".upload-button").on('click', function() {
       $(".file-upload").click();
    });
});