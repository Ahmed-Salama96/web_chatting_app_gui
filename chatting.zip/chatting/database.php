<?php
$con=mysqli_connect("localhost","root","ahmed115052", "users");
if(mysqli_connect_error())
{
   die("Sorry, Connection error!");
}
?>